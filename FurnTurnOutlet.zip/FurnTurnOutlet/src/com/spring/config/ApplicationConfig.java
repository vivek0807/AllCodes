package com.spring.config;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

// use appropriate annotations
@Configuration
@ComponentScan({"com.spring"})
public class ApplicationConfig {

}
