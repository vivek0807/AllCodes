package com.spring.main;

import com.spring.model.Product;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.spring.config.*;
import java.util.Scanner;
import com.spring.service.*;
public class Driver {

	public static void main(String[] args)  {

		Scanner in=new Scanner(System.in);
		// fill the code
		//in case of using an xml file
		//ApplicationContext context =new ClassPathXmlApplicationContext("beans.xml");
		ApplicationContext ctx= new AnnotationConfigApplicationContext(ApplicationConfig.class);
		ProductService ps= (ProductService)ctx.getBean("productService");
		System.out.println("Enter the product id:");
		String id=in.nextLine();
		System.out.println("Enter the product name:");
		String name=in.nextLine();
		System.out.println("Enter the mrp value:");
		double mrp = in.nextDouble();
		System.out.println("Enter the dimension details:");
		String dimension=in.nextLine();
		System.out.println("Enter the wood type:");
		String type=in.nextLine();
		double amt=ps.calculateBill(id,name,mrp,dimension,type);
		System.out.println("Amount to be paid is: "+amt);

	}

}
